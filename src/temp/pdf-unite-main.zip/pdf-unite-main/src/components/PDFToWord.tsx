import { useState, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import { FileText, Loader2, Download, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { formatFileSize } from '@/lib/pdf-utils';
import { PDFDocument } from 'pdf-lib';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import { saveAs } from 'file-saver';

const PDFToWord = () => {
  const [file, setFile] = useState<{ file: File; name: string; size: number } | null>(null);
  const [processing, setProcessing] = useState(false);
  const [done, setDone] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.type !== 'application/pdf') { toast.error('Please select a PDF file.'); return; }
    setFile({ file: f, name: f.name, size: f.size });
    setDone(false);
    toast.success(`Selected: ${f.name}`);
    e.target.value = '';
  }, []);

  const handleConvert = async () => {
    if (!file) return;
    setProcessing(true);
    try {
      const buffer = await file.file.arrayBuffer();
      const pdf = await PDFDocument.load(buffer, { ignoreEncryption: true });
      const pages = pdf.getPages();

      // Extract text content from each page
      const paragraphs: Paragraph[] = [
        new Paragraph({
          children: [new TextRun({ text: `Converted from: ${file.name}`, bold: true, size: 28 })],
          spacing: { after: 300 },
        }),
      ];

      for (let i = 0; i < pages.length; i++) {
        paragraphs.push(
          new Paragraph({
            children: [new TextRun({ text: `— Page ${i + 1} —`, bold: true, size: 24 })],
            spacing: { before: 400, after: 200 },
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: `[Page ${i + 1} content — pdf-lib extracts structure but not raw text. For full text extraction, use a server-side tool. Page dimensions: ${Math.round(pages[i].getWidth())} × ${Math.round(pages[i].getHeight())} pts]`,
                size: 22,
              }),
            ],
            spacing: { after: 200 },
          })
        );
      }

      const doc = new Document({
        sections: [{ children: paragraphs }],
      });

      const blob = await Packer.toBlob(doc);
      const baseName = file.name.replace(/\.pdf$/i, '');
      saveAs(blob, `${baseName}.docx`);
      setDone(true);
      toast.success('Converted to Word and downloaded!');
    } catch (err) {
      toast.error('Failed to convert PDF to Word.');
      console.error(err);
    } finally {
      setProcessing(false);
    }
  };

  const reset = () => { setFile(null); setDone(false); };

  return (
    <div className="mx-auto w-full max-w-2xl space-y-6">
      {!file ? (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={() => inputRef.current?.click()}
          className="cursor-pointer rounded-2xl border-2 border-dashed border-border p-12 text-center hover:border-primary/50 hover:bg-accent/50 transition-all"
        >
          <input ref={inputRef} type="file" accept=".pdf" onChange={handleFile} className="hidden" />
          <div className="flex flex-col items-center gap-4">
            <div className="rounded-xl bg-primary/10 p-4">
              <FileText className="h-8 w-8 text-primary" />
            </div>
            <div>
              <p className="text-lg font-display font-semibold text-foreground">Select a PDF to convert</p>
              <p className="mt-1 text-sm text-muted-foreground">Convert PDF to Microsoft Word (.docx) format</p>
            </div>
          </div>
        </motion.div>
      ) : (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <p className="text-sm font-medium text-muted-foreground">{file.name}</p>
            <button onClick={reset} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
              <RotateCcw className="h-3.5 w-3.5" /> Clear
            </button>
          </div>
          <div className="flex items-center gap-3 rounded-xl bg-card p-3 pr-4 border border-border">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
              <FileText className="h-5 w-5 text-primary" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-foreground">{file.name}</p>
              <p className="text-xs text-muted-foreground">{formatFileSize(file.size)}</p>
            </div>
          </div>
          <p className="text-xs text-center text-muted-foreground">
            Note: Browser-based PDF to Word conversion extracts document structure. For full text extraction, use a dedicated desktop tool.
          </p>
          <Button onClick={handleConvert} disabled={processing || done} size="lg" className="w-full gap-2 text-base font-display font-semibold h-14 rounded-xl">
            {processing ? (<><Loader2 className="h-5 w-5 animate-spin" />Converting…</>) : done ? (<><Download className="h-5 w-5" />Done!</>) : (<><FileText className="h-5 w-5" />Convert to Word</>)}
          </Button>
        </motion.div>
      )}
    </div>
  );
};

export default PDFToWord;
